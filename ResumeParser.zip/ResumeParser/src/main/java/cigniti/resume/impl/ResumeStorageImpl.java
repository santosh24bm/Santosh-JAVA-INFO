package cigniti.resume.impl;

import java.sql.Timestamp;
import java.util.HashMap;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cigniti.resume.entities.ResumeDetails;

@Repository
public class ResumeStorageImpl {

	@Autowired
	private SessionFactory sessionFactory;


	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	@Transactional
	public boolean saveResumeDetails(String skills, String fulltext, String filename ) {

		System.out.println("inside the saveResumeDetails ");
	//	sessionFactory = getSessionfactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		ResumeDetails resumeDtls = null;

	//	for (int i = 0; i < hmap.size(); i++) {
			resumeDtls = new ResumeDetails();
		
			resumeDtls.setResumetext(fulltext);
			resumeDtls.setSkills(skills);
			resumeDtls.setFilename(filename);
			resumeDtls.setDate(new Timestamp(System.currentTimeMillis()));

			session.save(resumeDtls);

			tx.commit();
			session.close();

	//	}
		return true;

	}

}
