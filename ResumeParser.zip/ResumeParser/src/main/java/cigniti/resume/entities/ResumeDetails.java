package cigniti.resume.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="resumedetails")
public class ResumeDetails implements Serializable {

	private static final long serialVersionUID = -2362862228512502901L;

	
	@Id
	@Column(name="id")
	private int id ;
	
	
	@Column(name="resumetext")
	private String resumetext;
	
	@Column(name="skills")
	private String skills;
	
	@Column(name="filename")
	private String filename;
	
	@Column(name="Date")
	private Timestamp Date;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getResumetext() {
		return resumetext;
	}

	public void setResumetext(String resumetext) {
		this.resumetext = resumetext;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Timestamp getDate() {
		return Date;
	}

	public void setDate(Timestamp date) {
		Date = date;
	}
	
	
}
