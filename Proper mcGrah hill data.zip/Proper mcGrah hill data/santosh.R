MGHill_new <- read.csv("~/MGHillForR_clean.csv" , sep="," ,header = TRUE)

MGHill_new$newDate <- as.Date(MGHill_new$Date , format = "%d/%m/%Y") 
MGHill_new$newDate

plot(MGHill_new$Total.Logins...EngradePro...ConnectED ~ MGHill_new$newDate )

#https://dzone.com/articles/seasonal-periods

MGHill_new_ts <- ts(MGHill_new$Total.Logins...EngradePro...ConnectED , frequency = 24 , start = 1)

plot(MGHill_new_ts)

# mean 

plot(aggregate(MGHill_new_ts, FUN = mean), ylab = "mchill (mean)")
# 24 hour data 
boxplot(MGHill_new_ts~cycle(MGHill_new_ts))


#check stationary 
#adf test 

library(tseries)

#Dickey Fuller test with the difference of logged values
adf.test(MGHill_new_ts, alternative="stationary" )


acf(MGHill_new_ts)
 pacf(MGHill_new_ts)
 
# acf(log(MGHill_new_ts))
# pacf(log(MGHill_new_ts)

library(forecast)
auto.arima(MGHill_new_ts)

fit <- arima(MGHill_new_ts, c(2,1,1),seasonal = list(order = c(2,1,1), period = 24))
fcLoginData <- predict(fit, n.ahead = 70*24)
ts.plot(MGHill_new_ts, fcLoginData$pred)
