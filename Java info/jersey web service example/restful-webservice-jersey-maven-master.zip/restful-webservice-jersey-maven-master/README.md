# RESTfulHelloWorld
RESTful Hello World example using Jersey and Maven

## About
Detailed explanation can be found here: [tutorial-academy.com](http://tutorial-academy.com/restful-webservice-jersey-maven/)
