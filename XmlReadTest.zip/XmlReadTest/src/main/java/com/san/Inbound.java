package com.san;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Inbound
{
    private String content;

    private boolean confirmed;

    private String type;

    public String getContent ()
    {
        return content;
    }
	@XmlElement
    public void setContent (String content)
    {
        this.content = content;
    }

    public boolean getConfirmed ()
    {
        return confirmed;
    }
    @XmlAttribute
    public void setConfirmed (boolean confirmed)
    {
        this.confirmed = confirmed;
    }

    public String getType ()
    {
        return type;
    }
	@XmlElement
    public void setType (String type)
    {
        this.type = type;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [content = "+content+", confirmed = "+confirmed+", type = "+type+"]";
    }
}