package com.san;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;



public class pkg
{
    private boolean confirmed;

    private String name;

    private cls[] cls;

    public boolean getConfirmed ()
    {
        return confirmed;
    }

    @XmlAttribute
    public void setConfirmed (boolean confirmed)
    {
        this.confirmed = confirmed;
    }

    public String getName ()
    {
        return name;
    }
	@XmlElement
    public void setName (String name)
    {
        this.name = name;
    }

    public cls[] getcls()
    {
        return cls;
    }

	@XmlElement
    public void setcls (cls[] cls)
    {
        this.cls = cls;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [confirmed = "+confirmed+", name = "+name+", class = "+cls+"]";
    }
}