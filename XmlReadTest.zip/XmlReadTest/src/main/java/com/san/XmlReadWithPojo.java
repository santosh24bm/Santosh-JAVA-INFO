package com.san;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class XmlReadWithPojo {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, JAXBException {
		   System.out.println( "Hello World!" );
	      /*  File fXmlFile = new File("/hello/abc.xml");
	    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	    	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	    	Document doc = dBuilder.parse(fXmlFile);*/
		//   System.setProperty("javax.xml.accessExternalSchema", "all");
		   
	    	JAXBContext context = JAXBContext.newInstance(dependencies.class);
	    	//Create Unmarshaller using JAXB context
	    	Unmarshaller unmarshaller  = context.createUnmarshaller();
	     
	    	dependencies depds = (dependencies) 
	    		unmarshaller.unmarshal(new File("C:/hello/abc.xml"));
	    	System.out.println("indie the main method ");
	    	System.out.println(depds.getpkg().toString());
	    	for(int i=0; i< depds.getpkg().length ;i++){
	    		pkg p = depds.getpkg()[i];
	    		//p.getConfirmed()
	    		System.out.println("is confirmed "+p.getConfirmed());
	    		System.out.println("p "+p.getName());
	    	/*	cls[] classarray = p.getcls();
	    		for(cls classname: classarray){
	    			System.out.println("CLass name "+classname.getName());
	    			Feature []featureArray = classname.getFeature();
	    			for(Feature featurename : featureArray){
	    				if(featurename.getConfirmed()){
	    					System.out.println(featurename.getName());
	    				}
	    			}
	    		}*/
	    		
	    	}
	    //	System.out.println(depds.getDependencies());

	}

}
