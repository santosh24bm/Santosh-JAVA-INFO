package com.san;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "dependencies")
public class dependencies {
	private pkg[] pkg;

	public pkg[] getpkg() {
		return pkg;
	}

	@XmlElement
	public void setpkg(pkg[] pkg) {
		this.pkg = pkg;
	}

	@Override
	public String toString() {
		return "ClassPojo [package = " + pkg + "]";
	}
}
