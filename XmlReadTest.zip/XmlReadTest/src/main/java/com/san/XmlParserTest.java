package com.san;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Hello world!
 *
 */
public class XmlParserTest 
{
    public static void main( String[] args ) throws ParserConfigurationException, SAXException, IOException
    {
        System.out.println( "Hello World!" );
        File fXmlFile = new File("/hello/abc.xml");
    	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    	Document doc = dBuilder.parse(fXmlFile);
    	
    	NodeList nodes = doc.getDocumentElement().getChildNodes();
    	for (int i = 0; i < nodes.getLength(); i++) {
    	  Node node = nodes.item(i);
    	  if (node instanceof Element) {
    	    Element childElement = (Element) node;
    	    Node nodeinsidepackage = node.it
    	    System.out.println("tag name: " + childElement.getTagName());
    	  }
    	}
    	
    	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
    	String rootelementname =  doc.getDocumentElement().getNodeName();
    	NodeList rootelemetList = doc.getElementsByTagName(rootelementname);
    	
     	Node childnode = rootelemetList.item(1);
     	System.out.println("child node new san "+childnode);
    	
    /*	NodeList image = doc.getElementsByTagName("Point");
    	Node singleTerminalNode = image.item(i);
    	Element firstLevel = (Element)singleTerminalNode;
    	NodeList value1Nodes = (firstLevel).getElementsByTagName("ImageFile");
    	int lengthofimage = value1Nodes.getLength();System.out.println("root elements "+rootelemetList.getLength());
    	*/
    	
    	for (int temp = 0; temp < rootelemetList.getLength(); temp++) {
    		Node nNode = rootelemetList.item(temp);
    		System.out.println("\nCurrent  node :" + nNode.getNodeName());
    		Node  node = nNode.getFirstChild();
    		System.out.println("Child Node "+node);
    		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
    			Element eElement = (Element) nNode;
    			System.out.println("Element "+eElement);
    		}	
    	  		
    		
    	}
    }
}
