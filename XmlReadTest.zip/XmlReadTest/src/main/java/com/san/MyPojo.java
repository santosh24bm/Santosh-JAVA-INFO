package com.san;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



public class MyPojo
{
    private dependencies dependencies;

    public dependencies getDependencies ()
    {
        return dependencies;
    }
   
    @XmlElement
    public void setDependencies (dependencies dependencies)
    {
        this.dependencies = dependencies;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [dependencies = "+dependencies+"]";
    }
}
	