package com.san;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class cls
{
    private boolean confirmed;

    private String name;

    private Feature[] feature;

    private Inbound[] inbound;

    public boolean getConfirmed ()
    {
        return confirmed;
    }
	@XmlAttribute
    public void setConfirmed (boolean confirmed)
    {
        this.confirmed = confirmed;
    }

    public String getName ()
    {
        return name;
    }
	@XmlElement
    public void setName (String name)
    {
        this.name = name;
    }

    public Feature[] getFeature ()
    {
        return feature;
    }
	@XmlElement
    public void setFeature (Feature[] feature)
    {
        this.feature = feature;
    }

    public Inbound[] getInbound ()
    {
        return inbound;
    }
	@XmlElement
    public void setInbound (Inbound[] inbound)
    {
        this.inbound = inbound;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [confirmed = "+confirmed+", name = "+name+", feature = "+feature+", inbound = "+inbound+"]";
    }
}
	