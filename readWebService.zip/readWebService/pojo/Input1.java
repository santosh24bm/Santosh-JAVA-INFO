package com.cogniti.ml.pojo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ColumnNames", "Values" })
public class Input1 {

	@JsonProperty("ColumnNames")
	private List<String> columnNames = null;
	
	@JsonProperty("Values")
	private List<List<String>> values = null;
	
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("ColumnNames")
	public List<String> getColumnNames() {
		return columnNames;
	}

	@JsonProperty("ColumnNames")
	public void setColumnNames(List<String> columnNames) {
		this.columnNames = columnNames;
	}

	@JsonProperty("Values")
	public List<List<String>> getValues() {
		return values;
	}

	@JsonProperty("Values")
	public void setValues(List<List<String>> values) {
		this.values = values;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
	
	@Override
    public String toString()
    {
        return "Input1 [columnNames = "+columnNames+", values = "+values+", additionalProperties = "+additionalProperties+"]";
    }
}