package com.cogniti.ml.pojo;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Inputs", "GlobalParameters" })
public class RequestResponseJSON {

	@JsonProperty("Inputs")
	private Inputs inputs;
	
	@JsonProperty("GlobalParameters")
	private GlobalParameters globalParameters;
	
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("Inputs")
	public Inputs getInputs() {
		return inputs;
	}

	@JsonProperty("Inputs")
	public void setInputs(Inputs inputs) {
		this.inputs = inputs;
	}

	@JsonProperty("GlobalParameters")
	public GlobalParameters getGlobalParameters() {
		return globalParameters;
	}

	@JsonProperty("GlobalParameters")
	public void setGlobalParameters(GlobalParameters globalParameters) {
		this.globalParameters = globalParameters;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
	
	@Override
    public String toString()
    {
        return "RequestResponseJSON [Inputs = "+inputs+", GlobalParameters = "+globalParameters+", additionalProperties = "+additionalProperties+"]";
    }
}